import React from "react";



class PropertyDetail extends React.Component{




    render()
    {
        return(<div>Seller Property detail</div>)
    }
}

export default PropertyDetail