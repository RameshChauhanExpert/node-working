import React from 'react';
import Typography from '@material-ui/core/Typography'
import { PropertySlider } from "../../index"
import './main.css'

export default class PropertyDetails extends React.Component {
   
  constructor(props)
  {
    super(props)
    
   
  }

  render() {
    var data=this.props.location.state.data
   console.log(data)
    return (

      <div class="property-details-wrapper">
    
        <div className="container-fluid">

          <div className="main-section">
            <div className="property-slider">
              <PropertySlider data={data} />
            </div>
            <div className="property-sidebar">
              <div className="property-name-wrap">
                <h3 className="property-name">3 BHK Apartments</h3>
                <p className="address-text">{data.street_address}</p>
              </div>
              <div className="features-list">
                <p>Details :<span>{data.sq_ft}k/sq.ft.</span></p>
              </div>
              <ul className="facility-list">
                <li>
                  <span className="icon"> <img src={require('./images/bed-icon.png')} /></span>
                  <span className="text">3 Bed</span>
                </li>
                <li>
                  <span className="icon"> <img src={require('./images/bath-icon.png')} /></span>
                  <span className="text">3 Bath</span>
                </li>
                <li>
                  <span className="icon"> <img src={require('./images/parking-icon.png')} /></span>
                  <span className="text">Parking</span>
                </li>
              </ul>

              <div className="description-text">
                <h6>About 3 BHK Apartment</h6>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumasan lacus
vel facilisis. </p>
                <a href="#" className="btn-link">See more details</a>
              </div>

              <div className="option-wrap">
                <ul>
                  <li>
                      <span><img src={require('./images/map-pin-icon.png')} /></span>
                      <h6>Map</h6>
                  </li>
                  <li>
                      <span><img src={require('./images/street-icon.png')} /></span>
                      <h6>Street</h6>
                  </li>
                  <li>
                      <span><img src={require('./images/direction-icon.png')} /></span>
                      <h6>Direction</h6>
                  </li>
                </ul>
              </div>

            </div>
          </div>

          <div className="properties-details">
          
            <Typography variant="subheading" className="subheading">Features</Typography>
            <div className="listing-wrapper">
              <Typography variant="h4" className="h4-heading">Basic Details</Typography>

              <ul className="flex-grid">
                <li>Type of Property: {data.type_of_property}</li>
                <li>Bedrooms: 3</li>
                <li>Bathrooms: 3</li>
                <li>Year Built: {data.year_built}</li>
                <li>Sq ft: {data.sq_ft}</li>
                <li>Garage: {(data.is_garage==0)?"No":"Yes"}</li>
                <li>Cooling System:{(data.cooling_system==0)?"No":"Yes"} </li>
                <li>Waste water system: {(data.sewer==0)?"No":"Yes"}</li>
              </ul>
            </div>

            <div className="listing-wrapper">
              <Typography variant="h4" className="h4-heading">Community Info</Typography>

              <ul className="flex-grid">
                <li>HOA:  {(data.hoa==0)?"No":"Yes"}</li>
                <li>Communities Aminities:  Pool, Gym, Spa</li>
                <li>Condo Association: {(data.condo_assocation==0)?"No":"Yes"}</li>
                <li>55+ Community:  {(data['55_community']==0)?"No":"Yes"}</li>
                <li>Rental Restrictions for new owners:  {(data.rental_restrictions==0)?"No":"Yes"}</li>
              </ul>
            </div>


            <Typography variant="subheading" className="subheading">House Condition</Typography>
            <div className="listing-wrapper">
              <ul className="flex-grid">
                <li>Kitchen: Single Family</li>
                <li>Bathroom: 3</li>
                <li>Interior Paint: 3</li>
                <li>Flooring: 2002</li>
                <li>Ac Unit(s): 2000</li>
                <li>Roof: No</li>
                <li>Exterior Paint: Central AC </li>
                <li>Windows: Septic</li>
                <li>Electrical panel: Septic</li>
                <li>Hot water heater: Septic</li>
                <li>Appliances: Septic</li>
                <li>Pool/Pool equipment(if applicable): Septic</li>
               
              </ul>
            </div>
            <Typography variant="subheading" className="subheading">Discription</Typography>
            <div className="description">
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumasan lacus vel facilisis. Sit amet, consectetur adipiscing elit, sed do risus commodo viverra maecenas accumsan lacus vel facilisis. sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Sit amet, consectetur adipiscing elit, sed do risus commodo viverra maecenas accumsan lacus vel facilisis. </p>
            </div>

            <Typography variant="subheading" className="subheading">Documents</Typography>
            <div className="listing-wrapper documents">
              <p>The following documents are available for Palm Harbor, Florida 34683 </p>
              <ul className="flex-wrap">
                <li> <span className="document-icon"><img src={require('./images/document-icon.png')} /></span>Brokerage Commissions Document <a href="#"><span className="download-icon"><img src={require('./images/download-icon.png')} /></span></a> </li>
                <li> <span className="document-icon"><img src={require('./images/document-icon.png')} /></span>Purchase and sale Agreement <a href="#"><span className="download-icon"><img src={require('./images/download-icon.png')} /></span></a> </li>
              </ul>
            </div>

            <Typography variant="subheading" className="subheading">Listed By</Typography>
            <div className="listing-wrapper">
              <ul className="flex-wrap">
                <li><span>Comapny Phone</span> <span className="hidden-text">*******************</span></li>
                <li><span>Agent Name</span> <span className="hidden-text">**********</span></li>
                <li><span>License Name</span> <span className="hidden-text">***********</span></li>
                <li><span>Address </span><span className="hidden-text">***********</span></li>
               
              </ul>
            </div>

            <Typography variant="subheading" className="subheading">Offerlane Firm</Typography>
            <div className="listing-wrapper">
              <ul className="flex-wrap">
                <li><span>Offerlane Licenses</span> <span className="text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</span></li>
              
               
              </ul>
            </div>
           

          </div>

        </div>
      </div>

    )

  }

}