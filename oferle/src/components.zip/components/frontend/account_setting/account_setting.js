import React from 'react';
import '../register/registration.css'
import { TextField, Button, Checkbox, Link ,connect,withRouter,Route} from "../../../utilities"
import{Loader} from "../../index"
import{TextBox} from "../../index"
import logo from "../../../assets/img/logo.png"
import {signup, submit_edit_profile_data} from "../../../action/"
import { constant } from '../../../config';
import comman_snackbar from '../../SnackBar/comman_snackbar';

class AccountSetting extends React.Component {

 constructor(props)
 {
super(props)
 this.state={
   first_name:"",
   last_name:"",
   email:"",
   password:"",
   phone:"",
   isValidate:this.isValidate,
   validate:false,
   image_url:""
 }
this.handleChange=this.handleChange.bind(this)
this.imageAction=this.imageAction.bind(this)
this.totalElement=5;
this.elementIndex=0;
this.isValidateAll=0;

 }

 imageAction(event)
 {
    var blobArray=Array.from(event.target.files)
    this.setState({image_url:URL.createObjectURL(blobArray[0])})
    
   
 }
 handleSubmit=(event)=>
 {
   this.elementIndex=0;
   this.isValidateAll=0
   event.preventDefault();
   this.setState({validate:true,finalCheckAll:"true",})
 }
 isValidate=(isValidate,validate)=>{
  
  
   if(isValidate==true)
   {
     
     this.elementIndex++;
   }

   this.setState({validate:validate},()=>{

   if(this.elementIndex==this.totalElement)
   {
              this.isValidateAll++
   
              if(this.isValidateAll==this.totalElement)
              {
                
                this.props.submit(this.state)
              }
              
   }
   
  })
   
 }
 handleChange(event)
 {
     this.setState({[event.target.name]:event.target.value})
 }
 componentDidMount()
 {
     this.setState(this.props.location.state.data,()=>{
         console.log("user detail in brif",this.state)
     })
 }
  render() {
    //alert(this.state.image_url)
   
    return (
      <div>

        <div className="row for_register_login">

          <div className="col-sm-6 figure-part">
            <img src={(this.state.image_url!="")?this.state.image_url:"https://www.sideshowtoy.com/assets/products/903305-super-powers-superman/lg/dc-comics-superman-maquette-tweeterhead-903305-09.jpg"} alt="" />
            
          </div>
          <div className="col-sm-6 form-part">

            <div className="card-wrapper">

              
              <form action="#" onSubmit={this.handleSubmit} className="form__wrapper ">
                <div className="form-fields">
                <div className="form-field register_signup">
                <input type="file" onChange={this.imageAction} />
                </div>
                  <div className="form-field register_signup">
                    
                    <TextBox label="First Name" 
                   type="text" 
                  value={this.state.first_name} 
                   name="first_name"
                   onBlur={false}
                   state={this.state} 
                   change={this.handleChange} 
                   validate={this.state.validate} 
                   className="input-conrtol" 
                   margin="normal"
                   required={[true,"Please enter first name"]}
                   max={[true,15,""]}
                   />
              
                  </div>

                 

                  <div className="form-field register_signup">
                    
                    <TextBox label="Last Name" 
                   type="text" 
                  value={this.state.last_name} 
                   name="last_name"
                   onBlur={false}
                   state={this.state} 
                   change={this.handleChange} 
                   validate={this.state.validate} 
                   className="input-conrtol" 
                   margin="normal"
                   required={[true,"Please enter last name"]}
                   max={[true,15,""]}
                   />
                  </div>
                </div>

                <div className="form-field register_signup">
                 
                  <TextBox label="Email" 
                   type="text" 
                  value={this.state.email} 
                
                   name="email"
                   onBlur={true}
                   state={this.state} 
                   change={this.handleChange} 
                   validate={this.state.validate} 
                   className="input-conrtol" 
                   margin="normal"
                   required={[true,"Please enter email"]}
                   max={[true,70,""]}
                   email={[true,"Sorry you entered invalid email"]}
                   />
                </div>

                <div className="form-field register_signup">
                <TextBox label="Password" 
                   type="password" 
                  value={this.state.password} 
                   name="password"
                   onBlur={false}
                   state={this.state} 
                   change={this.handleChange} 
                   validate={this.state.validate} 
                   className="input-conrtol" 
                   margin="normal"
                   required={[true,"Please enter password"]}
                   max={[true,50,""]}
                   />
                </div>
                <div className="form-field register_signup">
                <TextBox label="Phone" 
                   type="text" 
                  value={this.state.phone} 
                   name="phone"
                   onBlur={false}
                   state={this.state} 
                   change={this.handleChange} 
                   validate={this.state.validate} 
                   className="input-conrtol" 
                   margin="normal"
                   required={[true,"Please enter phone number"]}
                   max={[true,10,""]}
                   min_value={[true,0,"Please enter valid phone number"]}
                   only_number={[true,"Phone number support only number"]}
                   
                   />
                </div>
                

                <button type="submit" className="btn-large btn-primary"  >Submit</button>


              </form>

              
            </div>


          </div>

        </div>
        
       {(this.props.state.utilities.loader==true)? <Loader/>:""}    
       <comman_snackbar state={this.props.state.utilities.snackbar} />     
      </div>

    )

  }

}

const mapStateToProps = state => ({
  state
})
const actionCall = dispatch => ({
  submit:(state)=>{dispatch(submit_edit_profile_data(state))}
})
export default withRouter(connect(mapStateToProps,actionCall)(AccountSetting))