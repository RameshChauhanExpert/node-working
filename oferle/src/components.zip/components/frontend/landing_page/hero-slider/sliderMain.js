import React, { Component } from "react";

import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import LinearProgress from '@material-ui/core/LinearProgress';
import Slider from "react-slick";
import './banner.css';
import {LinearBuffer} from "../../../index";
import {library,FontAwesomeIcon,faFacebookF,faTwitter,faLinkedinIn} from "../../../../utilities"
library.add(faFacebookF,faTwitter,faLinkedinIn)

export default class HomeSlider extends Component {
  constructor(){
    super()
    this.state={path:["../hero-slider/img/slide-01.jpg",
    "../hero-slider/img/slide-02.jpg",
    "../hero-slider/img/slide-03.jpg",
   "../hero-slider/img/slide-04.jpg"]
  ,position:1
  }
  }
  componentDidMount(){
    
    this.setState({totalImage:this.state.path.length})
  }
  render() {
    const settings = {
      dots: true,
      nav:false,
      infinite: true,
      slidesToShow: 1,
      slidesToScroll: 1,
      autoplay: true,
      speed: 1000,
      autoplaySpeed:4000,
      arrows:false,
      beforeChange:(current,next)=>{
      this.setState({position:next+1})
      }
    };
    
    return (
      <div className="hero-slider">
      
       <Slider {...settings}>
          {this.state.path.map(path=>{
            return(<div>
            <img alt="picture" src={require('../hero-slider/img/slide-01.jpg')} />
          </div>)
          })}
        </Slider>
            
       
        <ul className="social-icon">
          <li data-aos="fade-up" data-aos-duration="400">
            <a href="#">
              <FontAwesomeIcon icon={['fab', 'facebook-f']} /></a>

          </li>
          <li data-aos="fade-up" data-aos-duration="700">
            <a href="#">
              <FontAwesomeIcon icon={['fab', 'twitter']} /></a>
          </li>
          <li data-aos="fade-up" data-aos-duration="1000">
            <a href="#">
              <FontAwesomeIcon icon={['fab', 'linkedin-in']} /></a>

          </li>
        </ul>
        
         {/* <span className="slide_count">{this.state.position} out of {this.state.path.length}</span> 
      */}
      </div>
    );
  }
}



const styles = {
  root: {
    flexGrow: 1,
  },
};

class LinearDeterminate extends React.Component {
  constructor(props)
  {
    super(props)
    this.state = {
      completed: 0,
    };
    this.cur=1;
    this.pre=1;
    this.comp=0
  }
  
  
componentDidMount()
{
  setInterval(function(){
    this.comp
  })
}
 

  render() {
    
   this.cur=this.props.state
   var comp=0
   
   if(this.cur!=this.pre)
   {
    this.pre=this.cur;
     comp=100;
   
    setTimeout(function(){comp=0},1)
   
     
   }
   
    return (
      <div >
        
        <LinearProgress variant="determinate" value={0}  />
        <br />
       
      </div>
    );
  }
}

LinearDeterminate.propTypes = {
  classes: PropTypes.object.isRequired,
};

  withStyles(styles)(LinearDeterminate)