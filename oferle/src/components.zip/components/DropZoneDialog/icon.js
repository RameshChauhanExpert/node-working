import React from 'react'

export const Icon = (props) => {
  return (<div data-filetype={props.filetype} className='filepicker-file-icon' />)
}