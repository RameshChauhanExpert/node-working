import React from 'react';
import './login.css'
import { TextField, Button, Checkbox, Link,connect,withRouter,Switch,Redirect,Route} from "../../../../utilities"
import logo from "../../../../assets/img/logo.png"
import {login,loginState} from "../../../../action/login/login"
import {FadeSnackbar} from "../../../index"
import {Routing,AfterLogin,constant} from "../../../../config/";
import {TextBox} from "../../../index";
import Loader from '../../../loader/loader';
/* 
Login Component for front end
*/

class BuyerLogin extends React.Component {

constructor(props)
{
  super(props);
  this.handleChange=this.handleChange.bind(this)
  this.snackBarClose=this.snackBarClose.bind(this)
}
handleChange(event)
{

    this.props.loginState(event)
}

snackBarClose(event)
{
  var data={target:{name:"status",value:402}}


  setTimeout(function(){ this.props.loginState(data) }.bind(this),500);
  
}

  render() {
  var {loader}=this.props.state.utilities
   if(this.props.state.login_component.status==200)
   {
    localStorage.setItem("login",true);
    localStorage.setItem("token_id",this.props.state.login_component.user_detail[0].user_id)
    
    this.props.loginState({target:{name:"login",value:true}})
    
    return(
      <Switch>
    <AfterLogin/>
    {
      this.props.history.push(constant.frontend_url.buyer_dashboard)
    }
    </Switch>
    )
   }
   if(localStorage.getItem("login")=="true")
   {
     this.props.history.push(constant.frontend_url.buyer_dashboard)
   }
   
    return (
      <div>
        <div className="row for_register_login">
        <div className="col-sm-6 figure-part">
          {/* <img src={require('../../../../assets/img/login-figure.jpg')} alt="" /> */}
        </div>
        <div className="col-sm-6 form-part login_form">
        <div className="card-wrapper">
         <div className="logo">
           <Link to="/"> <img src={logo} alt="" /></Link>
         </div> 
         <div className="tagline">Welcome back to offerlane</div>
        <form action="/seller-dashboard"  post="form" className="form__wrapper">
        <div className="form-field">
          <TextField 
           label="Email/Phone*" 
           
           type="text"
           name="email" 
         
           margin="normal"
           color="primary"
           className="input-conrtol"
           value={this.props.state.login_component.email}
           onChange={this.props.loginState}
            />
            
        </div>
        <div className="form-field">
          <TextField 
          label="Password*" 
          type="password"
          name="password"
         value={this.props.state.login_component.password}
          margin="normal" 
          color="primary" 
          className="input-conrtol" 
          onChange={this.props.loginState}
          />
        </div>
        <div className="link-text"> <Link to={constant.frontend_url.forgot_password}>Forgot Password?</Link></div>
        <button type="button" className="btn-large btn-primary" onClick={this.props.login}>Sign In</button>
        </form>

        <p className="info-link">Don’t have account?<a className="sign_up" href="/register"> SIGN UP</a> </p>
        </div>
        </div>
        </div>
        <FadeSnackbar onclose={this.snackBarClose} snackbar={{show:(this.props.state.login_component.status==401)?true:false,message:this.props.state.login_component.message}} />
        
        {(loader==true)?<Loader  />:""}
      
 
      </div>
    )
  }
}
const mapStateToProps = state => ({
	state
})
const actionCall = dispatch => ({
  login:()=>{dispatch(login())},
  loginState:(event)=>{dispatch(loginState(event))}
})
export default withRouter(connect(mapStateToProps,actionCall)(BuyerLogin))