import React from 'react';
import{LocationSearchInput}from"../../../index"

export default class ProperySearch extends React.Component {
    render() {
        return (

            <div className="property-search-block">
            
                <h1 data-aos="fade-up" data-aos-duration="1000">Get your property offer <br/>in <span className="primary-color">24 Hours</span></h1>
                <p data-aos="fade-up" data-aos-duration="1000" className="lead-content">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
                <div data-aos="fade-up" data-aos-duration="1000" className="search_form location-search">
                    <form>
                    <LocationSearchInput class="input-text" placeholder="Enter Your Property Address " />
                        {/* <input type="text" className="input-text" placeholder="Enter Your Property Address " /> */}
                        <button type="submit" className="submit-btn">GO</button>
                    </form>
                    
                </div>

            </div>

        )

    }
}