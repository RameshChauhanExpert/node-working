import React from  "react"
import {Link,Switch,Route} from "react-router-dom"

import SellerPropertyListing from "./property_list"
import AccountSetting from "../account_setting/account_setting"
import { constant } from "../../../config";
export class Routing extends React.Component{



    render()
    {
        return(
            <Switch>
 
     <Route  path={constant.frontend_url.seller_property_list} component={SellerPropertyListing} />
     <Route  path={constant.frontend_url.seller_account_setting} component={AccountSetting} />

            </Switch>
        )
    }
}