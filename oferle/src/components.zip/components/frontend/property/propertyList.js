import React from 'react';
import './main.css'
import { TextField, Typography, MenuItem, Button, Select } from "../../../utilities"
import { LocationSearchInput, GoogleMarkerMap } from "../../index"

export default class PropertyList extends React.Component {
    constructor(props) {
        super(props);
        this.handlechange = this.handlechange.bind(this);
        this.state = { status: "" }
    }
    handlechange(event) {
        this.setState({ [event.target.name]: event.target.value })

    }

    render() {
        return (
            <div class="property-list-wrapper">
                <div className="filter-section">
                    <div className="container-fluid">
                        <form action="#">
                            <div class="search-input-wrap">
                                <LocationSearchInput class="search-input" plaeholder="Enter Your Property Address " />
                            </div>
                            <Select name="status" variant="outlined" className="select-box"
                                value={this.state.status}
                                onChange={this.handlechange}
                                label="State"
                            >
                                <MenuItem value="1">Florida</MenuItem>

                            </Select>

                            <Select name="status" variant="outlined" className="select-box"
                                value={this.state.status}
                                onChange={this.handlechange}
                                label="County"
                            >
                                <MenuItem value="1">1</MenuItem>
                                <MenuItem value="0">2</MenuItem>
                            </Select>
                        </form>


                    </div>
                </div>

                <div className="row">
                    <div className="col-sm-6 property-list">
                        <div className="totle-count">1000 Properties</div>

                        <div className="list-row">
                            <div className="figure">
                                <img src={require('./images/property-01.jpg')} />
                            </div>
                            <div className="property-details">
                                <div className="property-name-wrap">
                                    <h3 className="property-name">3 BHK Apartments</h3>
                                    <p className="address-text">Palm Harbor, Florida 34683</p>
                                </div>
                                <div className="features-list">
                                    <p>Details :<span>5.56k/sq.ft.</span></p>
                                    <p>Status : <span>Unfurnished, Immediately Available</span></p>
                                </div>
                                <ul className="facility-list">
                                    <li>
                                        <span className="icon"> <img src={require('./images/bed-icon.png')} /></span>
                                        <span className="text">3 Bed</span>
                                    </li>
                                    <li>
                                        <span className="icon"> <img src={require('./images/bath-icon.png')} /></span>
                                        <span className="text">3 Bath</span>
                                    </li>
                                    <li>
                                        <span className="icon"> <img src={require('./images/parking-icon.png')} /></span>
                                        <span className="text">Parking</span>
                                    </li>
                                </ul>
                                <div className="actions">
                                    <a href="#" className="wishlist">Wishlist</a>
                                    <a href="#" className="offer-btn">Submit Offer</a>
                                </div>
                            </div>

                        </div>
                        <div className="list-row">
                            <div className="figure">
                                <img src={require('./images/property-01.jpg')} />
                            </div>
                            <div className="property-details">
                                <div className="property-name-wrap">
                                    <h3 className="property-name">3 BHK Apartments</h3>
                                    <p className="address-text">Palm Harbor, Florida 34683</p>
                                </div>
                                <div className="features-list">
                                    <p>Details :<span>5.56k/sq.ft.</span></p>
                                    <p>Status : <span>Unfurnished, Immediately Available</span></p>
                                </div>
                                <ul className="facility-list">
                                    <li>
                                        <span className="icon"> <img src={require('./images/bed-icon.png')} /></span>
                                        <span className="text">3 Bed</span>
                                    </li>
                                    <li>
                                        <span className="icon"> <img src={require('./images/bath-icon.png')} /></span>
                                        <span className="text">3 Bath</span>
                                    </li>
                                    <li>
                                        <span className="icon"> <img src={require('./images/parking-icon.png')} /></span>
                                        <span className="text">Parking</span>
                                    </li>
                                </ul>
                                <div className="actions">
                                    <a href="#" className="wishlist">Wishlist</a>
                                    <a href="#" className="offer-btn">Submit Offer</a>
                                </div>
                            </div>

                        </div>
                        <div className="list-row">
                            <div className="figure">
                                <img src={require('./images/property-01.jpg')} />
                            </div>
                            <div className="property-details">
                                <div className="property-name-wrap">
                                    <h3 className="property-name">3 BHK Apartments</h3>
                                    <p className="address-text">Palm Harbor, Florida 34683</p>
                                </div>
                                <div className="features-list">
                                    <p>Details :<span>5.56k/sq.ft.</span></p>
                                    <p>Status : <span>Unfurnished, Immediately Available</span></p>
                                </div>
                                <ul className="facility-list">
                                    <li>
                                        <span className="icon"> <img src={require('./images/bed-icon.png')} /></span>
                                        <span className="text">3 Bed</span>
                                    </li>
                                    <li>
                                        <span className="icon"> <img src={require('./images/bath-icon.png')} /></span>
                                        <span className="text">3 Bath</span>
                                    </li>
                                    <li>
                                        <span className="icon"> <img src={require('./images/parking-icon.png')} /></span>
                                        <span className="text">Parking</span>
                                    </li>
                                </ul>
                                <div className="actions">
                                    <a href="#" className="wishlist">Wishlist</a>
                                    <a href="#" className="offer-btn">Submit Offer</a>
                                </div>
                            </div>

                        </div>
                        <div className="list-row">
                            <div className="figure">
                                <img src={require('./images/property-01.jpg')} />
                            </div>
                            <div className="property-details">
                                <div className="property-name-wrap">
                                    <h3 className="property-name">3 BHK Apartments</h3>
                                    <p className="address-text">Palm Harbor, Florida 34683</p>
                                </div>
                                <div className="features-list">
                                    <p>Details :<span>5.56k/sq.ft.</span></p>
                                    <p>Status : <span>Unfurnished, Immediately Available</span></p>
                                </div>
                                <ul className="facility-list">
                                    <li>
                                        <span className="icon"> <img src={require('./images/bed-icon.png')} /></span>
                                        <span className="text">3 Bed</span>
                                    </li>
                                    <li>
                                        <span className="icon"> <img src={require('./images/bath-icon.png')} /></span>
                                        <span className="text">3 Bath</span>
                                    </li>
                                    <li>
                                        <span className="icon"> <img src={require('./images/parking-icon.png')} /></span>
                                        <span className="text">Parking</span>
                                    </li>
                                </ul>
                                <div className="actions">
                                    <a href="#" className="wishlist">Wishlist</a>
                                    <a href="#" className="offer-btn">Submit Offer</a>
                                </div>
                            </div>

                        </div>
                        <div className="list-row">
                            <div className="figure">
                                <img src={require('./images/property-01.jpg')} />
                            </div>
                            <div className="property-details">
                                <div className="property-name-wrap">
                                    <h3 className="property-name">3 BHK Apartments</h3>
                                    <p className="address-text">Palm Harbor, Florida 34683</p>
                                </div>
                                <div className="features-list">
                                    <p>Details :<span>5.56k/sq.ft.</span></p>
                                    <p>Status : <span>Unfurnished, Immediately Available</span></p>
                                </div>
                                <ul className="facility-list">
                                    <li>
                                        <span className="icon"> <img src={require('./images/bed-icon.png')} /></span>
                                        <span className="text">3 Bed</span>
                                    </li>
                                    <li>
                                        <span className="icon"> <img src={require('./images/bath-icon.png')} /></span>
                                        <span className="text">3 Bath</span>
                                    </li>
                                    <li>
                                        <span className="icon"> <img src={require('./images/parking-icon.png')} /></span>
                                        <span className="text">Parking</span>
                                    </li>
                                </ul>
                                <div className="actions">
                                    <a href="#" className="wishlist">Wishlist</a>
                                    <a href="#" className="offer-btn">Submit Offer</a>
                                </div>
                            </div>

                        </div>

                    </div>
                    <div className="col-sm-6 map-iframe">
                        <GoogleMarkerMap/>
                    </div>
                </div>
            </div>

        )

    }

}