import React from "react"


 class BuyerPropertyDetail extends React.Component
{
    render()
    {
        return(<div>Buyer Propert Deatil</div>)
    }
}

export default BuyerPropertyDetail