import React from "react"
import { Switch,Route } from "../../../utilities";
import { constant } from "../../../config";
import BuyerLogin from "./buyer_login/buyer_login";
import BuyerDashboard from "./buyer_dashboard/buyer_dashboard"
import BuyerPropertyDetail from "./buyer_dashboard/buyer_property_detail/buyer_property_detail";


class Routing extends React.Component{


    render()
    {
        return(
            <Switch>
              <Route  path={constant.frontend_url.buyer_login} component={BuyerLogin} />
              <Route  path={constant.frontend_url.buyer_dashboard} component={BuyerDashboard} />
              

            </Switch>
        )
    }
}


export default Routing