import React from "react";




export default class Page_not_found extends React.Component{


    render(){
        return(<div>

            <img src={require("../../../assets/img/page_not_found/error-image (1).png")} />
        </div>)
    }
}