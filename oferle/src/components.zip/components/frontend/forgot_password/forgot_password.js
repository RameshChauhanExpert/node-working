import React from "react";
import '../forgot_password/forgot_password.css'
import {TextField} from "../../../utilities"




class ForgotPassword extends React.Component{


    constructor(props)
    {
       super(props)
    }


    render()
    {
        return(<div> <div className="forgot_password_wrapper">
        <div className="all_filed_password"><div className="forgot_password_info"><h1>Forgot Password</h1><p>Please enter your email address below and we will send you information to change your password.</p></div>
        <div className="forgot_text_field">
        <form className="form__wrapper">
        <TextField label="Enter your email address"/>
        <button type="button" className="btn-large btn-primary" onClick={this.props.login}>Submit</button>
        </form>
        </div></div>
        </div> </div>)
    }
}


export default ForgotPassword