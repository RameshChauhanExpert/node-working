import React from "react"
import Routing from "./routing"


class Buyer extends React.Component{




    render()
    {
        return(<div><Routing/></div>)
    }
}


export default Buyer