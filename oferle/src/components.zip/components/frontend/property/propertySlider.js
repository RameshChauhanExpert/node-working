import React from 'react';
import { constant } from '../../../config';
export default class PropertySlider extends React.Component {

    render(){
       var data= this.props.data
        return(

                <div>
                   
                  <img src={(data.image_base_64==null)?require('./images/property-slide-1.jpg'):constant.file_url+data.image_base_64} />
                </div>
            )

        }

}