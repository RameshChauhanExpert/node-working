// import 'rc-slider/assets/index.css';

// import React from 'react';
// import ReactDOM from 'react-dom';
// import Slider from 'rc-slider';

// const style = { width: 400, margin:0 };
// const marks = {
  
//     0: <span>0</span>,
//     9: <div className="range_title">
//     <div className="col-lg-12"><span className="average-range">1</span></div><div className="col-lg-12"><span className="average_label good-range">Average</span></div>
//       </div>,
//     18: '2',
//     27: '3',
//     36: '4',
//     45: <div className="range_title">
//   <div className="col-lg-12"><span className="good-range">5</span></div><div className="col-lg-12"><span className="good_label good-range">Good</span></div>
//     </div>,
//     54: '6',
//     63: '7',
//     72: '8',
//     81: '9',
//     90: <div className="range_title">
//     <div className="col-lg-12"><span className="perfect-range">10</span></div><div className="col-lg-12"><span className="perfect_label good-range">Perfect</span></div>
//       </div>,
//     100: <span>N/A</span>,
// };

// function log(value) {
//   console.log(value); //eslint-disable-line
// }
//   export default class RangeSlider extends React.Component{
//       constructor(props){
//           super(props)
//           this.handlechange=this.handlechange.bind(this);
//       }
//       handlechange(value)
//       { 
    //var number=0

//         if(value==0)
//           {
//               number=0
//           }
//           if(value==9)
//           {
//               number=10
//           }
//           if(value==18)
//           {
//               number=20
//           }
//           if(value==27)
//           {
//               number=30
//           }if(value>36)
//           {
//               number=40
//           }if(value==45)
//           {
//               number=50
//           }if(value==54)
//           {
//               number=60
//           }if(value==63)
//           {
//               number=70
//           }if(value==72)
//           {
//               number=80
//           }if(value==81)
//           {
//               number=90
//           }if(value>90)
//           {
//               number=100
//           }
//           if(value>100)
//           {
//               number=100
//           }
          
         
        
//          var event={target:{name:this.props.name,value:number}}  
      
//           this.props.change(event)
//       }
//       render(){
//           return(
//     <div className="range-slider-wrap">
    
//       <Slider min={0} number={this.props.value} onChange={this.handlechange} marks={marks} name={this.props.name} step={null}   />
   
//           </div>)
//       }
//   }



import 'rc-slider/assets/index.css';

import React from 'react';
import ReactDOM from 'react-dom';
import Slider from 'rc-slider';
import "./RangeSlider.css"
const style = { width: 400, margin:0 };
const marks = {
    0: <span>0</span>,
    10: <div className="range_title">
    <div className="col-lg-12"><span className="average-range">1</span></div><div className="col-lg-12"><span className="average_label good-range range_label">Average</span></div>
      </div>,
    20: '2',
    30: '3',
    40: '4',
    50: <div className="range_title">
  <div className="col-lg-12"><span className="good-range">5</span></div><div className="col-lg-12"><span className="good_label good-range range_label">Good</span></div>
    </div>,
    60: '6',
    70: '7',
    80: '8',
    90: '9',
    100: <div className="range_title">
    <div className="col-lg-12"><span className="perfect-range">10</span></div><div className="col-lg-12"><span className="perfect_label good-range range_label">Perfect</span></div>
      </div>,
};

function log(value) {
  console.log(value); //eslint-disable-line
}
  export default class RangeSlider extends React.Component{
      constructor(props){
          super(props)
          this.handlechange=this.handlechange.bind(this);
      }
      handlechange(value)
      { 
          var event={target:{name:this.props.name,value:value}}  
       // alert(this.props.name+"---"+event.target.name)
          this.props.change(event)
      }
      render(){
          
          return(
    <div className="range-slider-wrap">
    
      <Slider min={0} value={this.props.value} onChange={this.handlechange} marks={marks} name={this.props.name} step={null}   />
   
          </div>)
      }
  }






  