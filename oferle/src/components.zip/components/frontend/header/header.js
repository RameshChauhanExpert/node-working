import React from 'react';
import logo from '../../../logo.png';
import loginIcon from '../../../assets/img/login-icon.png';
import './header.css'
import {Button,TextField,Paper,Typography,AppBar,Toolbar,Link,withRouter} from "../../../utilities"
import withStyles from "@material-ui/core/styles/withStyles";
import {connect} from "../../../utilities"
import { constant } from '../../../config';

 class Header extends React.Component {
    render() {
        return (
            <div className="header">
              <div className="container-fluid">
                <div className="logo">
                <Link to="/">  
                    <img src={logo} alt="" />
                 </Link>
                </div>
                <div className="nav-left">
                  <ul>
                    <li><Link to={constant.frontend_url.about}>About Us</Link></li>
                    <li><Link to={constant.frontend_url.how_it_work}>How it Works</Link></li>
                    <li><Link to={constant.frontend_url.seller_wizard}>Sell</Link></li>
                    <li><Link to={constant.frontend_url.buyer_login} >Buy</Link></li>
                    <li><Link to={constant.frontend_url.contact}>Contact Us</Link></li>
                  </ul>
                </div>
     
      {(this.props.state.login_component.login!=true)?
      <div className="nav-right">
                    <ul>
                      <li className="nav-link"><Link to="/login"><span className="icon sign-in"></span> Sign In</Link></li>
                    </ul>
                </div>:<div className="nav-right">
                    <ul>
                      <li className="nav-link"><Link to="/login"><span className="icon sign-in"></span> Dashboard</Link></li>
                    </ul>
                </div>
              }
                


              </div>
            </div>
        )
                
    }
                
                
}

const mapStateToProps = state => ({
	state
})

export default withRouter(connect(mapStateToProps)(Header))